/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package monthlycheckin;

import java.io.Serializable;

/**
 *
 * @author karlvincentcuaresma
 */
public class familyNumber extends Address implements Serializable{
    protected String childNumber, totalNumber;

    public familyNumber() {
    }

    public familyNumber(String childNumber, String totalNumber) {
        this.childNumber = childNumber;
        this.totalNumber = totalNumber;
        
    }

    public String getChildNumber() {
        return childNumber;
    }

    public void setChildNumber(String childNumber) {
        this.childNumber = childNumber;
    }

    public String getTotalNumber() {
        return totalNumber;
    }

    public void setTotalNumber(String totalNumber) {
        this.totalNumber = totalNumber;
    }

    @Override
    public String toString() {
        return "familyNumber{" + "childNumber=" + childNumber + ", totalNumber=" + totalNumber + '}';
    }
    
    
    
    
}
